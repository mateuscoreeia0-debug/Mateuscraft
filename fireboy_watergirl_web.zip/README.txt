# Fireboy & Watergirl Elements — versão para navegador

Esta pasta foi extraída da parte web presente no APK enviado e ajustada para iniciar como aplicação web.

## Como usar
1. Extraia este ZIP.
2. Abra a pasta no Spck Editor.
3. Use o `index.html` como página principal.
4. Se o navegador bloquear algum recurso ao abrir como `file://`, rode o projeto por um servidor local/preview do Spck.

Observação: o APK original usa Cordova. A versão aqui remove o carregamento do Cordova e muda o alvo do jogo para `web`. Recursos exclusivos do Android, como anúncios nativos e armazenamento nativo, podem não funcionar no navegador.
